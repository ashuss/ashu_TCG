/*package com.cg.simulator.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.simulator.core.SimulatorCore2;
import com.cg.simulator.dto.AwsConnector;

import com.cg.simulator.util.HandleRestCalls;

@RestController

@RequestMapping("//simulator")
public class SimulatorController {

	private static String ButtonText = "OFF";
	private static String BtnSingle = "";
	private static String BtnDouble = ""; 
	private static boolean DoorStatus = false;
	private static String Leakage = "";
	private static String LeakageRate = "";
	private static String Magnetron = "";
	private static int Count = 0;
	private static Logger log = LoggerFactory.getLogger(SimulatorController.class);
	private SimulatorCore2 simulatorCore = new SimulatorCore2();

	@RequestMapping(value = "/insertData", method = RequestMethod.POST)
	public String updateSignal(@RequestBody Map<String, Object> jsonData) {
		System.out.println(jsonData.toString());
		String buttonText = (String) jsonData.get("btnText");
		String btnSingle = (String) jsonData.get("btnSingle");
		String btnDouble = (String) jsonData.get("btnDouble");
		boolean doorStatus = (boolean) jsonData.get("doorStatus");
		if (Count == 0) {
			try {

				simulatorCore.doorStatus("Closed", true);
				DoorStatus = false;
			} catch (InterruptedException e2) {

				e2.printStackTrace();
			}

			Count = Count + 1;
		} else {
			if (doorStatus == true) {
				try {
					simulatorCore.doorStatus("Open", false);
					DoorStatus = true;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			} else {
				try {
					simulatorCore.doorStatus("Closed", false);
					DoorStatus = false;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			}
		}

		if (btnSingle.equals("Single")) {
			BtnSingle = "Single";
			simulatorCore.sandwich(1);

		}

		if (btnDouble.equals("Double")) {
			BtnDouble = "Double";
			simulatorCore.sandwich(2);

		}
		if (buttonText.equals("ON")) {
			if (ButtonText == "OFF") {
				ButtonText = "ON";
				String leakage = (String) jsonData.get("leakage");
				String leakageRate = (String) jsonData.get("leakageRate");
				String magnetron = (String) jsonData.get("magnetron");
				Leakage = leakage;
				LeakageRate = leakageRate;
				Magnetron = magnetron;
				simulatorCore.leakageData(leakage, leakageRate, magnetron);
				simulatorCore.on();
			}
		} else {
			ButtonText = "OFF";
			simulatorCore.off();
		}

		return "yes";
	}

	@RequestMapping(value = "/getStatus", method = RequestMethod.GET)
	public Map<String, Object> getStatus() {

		System.out.println("*********hit controller****************");
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("btnSingle", BtnSingle);
		map.put("btnText", ButtonText);
		map.put("btnDouble", BtnDouble);
		map.put("doorStatus", DoorStatus);
		map.put("leakage", Leakage);
		map.put("leakageRate", LeakageRate);
		map.put("magnetron", Magnetron);

		return map;

	}


}*/