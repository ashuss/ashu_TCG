package com.cg.simulator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootApp {

	public static void main(String[] args) {
		System.setProperty("http.proxyHost", "cis-india-pitc-bangalorez.proxy.corporate.ge.com");
		System.setProperty("http.proxyPort", "80");
		System.setProperty("https.proxyHost", "cis-india-pitc-bangalorez.proxy.corporate.ge.com");
		System.setProperty("https.proxyPort", "80");
		SpringApplication.run(SpringBootApp.class, args);
	}

}