import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule, MatSelectModule} from '@angular/material';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material';
import { UserserviceService } from './userservice.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule, Http } from '@angular/http';
import { LoginPageComponent } from './login-page/login-page.component';
import { RouterModule, Routes } from '@angular/router';
import { ToastrModule } from 'ngx-toastr';
import { ToastrService } from 'ngx-toastr';
import { HomePageComponent } from './home-page/home-page.component';
import { SlideshowModule } from 'ng-simple-slideshow';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { BirthdayComponent } from './birthday/birthday.component';
import { NotificationComponent } from './notification/notification.component';

const appRoutes: Routes = [
  {
    path: '',
    component: LoginPageComponent
  },
  {
    path: 'Home',
    component: HomePageComponent
  },
  {
    path: 'Add',
    component: AddCustomerComponent
  },
  


];

@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    HomePageComponent,
    AddCustomerComponent,
    BirthdayComponent,
    NotificationComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatCardModule,
    MatFormFieldModule,                                                                                                                                                                                                                                                                                                                                 
    MatDatepickerModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatInputModule,
    MatNativeDateModule,
    HttpClientModule,
    HttpModule,
    RouterModule.forRoot(appRoutes),
    ToastrModule.forRoot(),
    SlideshowModule
  ],
  providers: [UserserviceService,ToastrService],
  bootstrap: [AppComponent]
})
export class AppModule { }
