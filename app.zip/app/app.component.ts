import { Component } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserserviceService } from './userservice.service';
import { Http, Response } from '@angular/http';
import  {  HttpClient,  HttpHeaders }  from  '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  flag: boolean;
  date1: any;
  toDate: string;
  date2: any;
  mobile: any;
  date: any;
  cName: any;
  title = 'app';
  formdata;

  constructor(private userservice: UserserviceService) { }

  ngOnInit() {
    this.formdata = new FormGroup({
      cname: new FormControl(),
      phone: new FormControl(),
      date: new FormControl()
    });
  }

  onClickSubmit(data) {
    this.cName = data.cname;
    let date1 = data.date;
    this.toDate = `${date1.getFullYear()}-${date1.getMonth() + 1}-${date1.getDate()}`;
    console.log("from calenadr  ",date1);
    this.date2 = date1[0];
    console.log(this.date2);
    this.mobile = data.phone;
    console.log(this.cName, this.toDate, this.mobile);

    let dataObject = {
      "userName": this.cName,
      "mobileNo": this.mobile,
      "birthDate": date1
    }

    this.userservice.saveCustomerData(dataObject).subscribe((response : any) => {
      console.log("POST Request is successful ", response);
      
    });
  }
}
