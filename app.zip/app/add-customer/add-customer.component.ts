import { Component, OnInit } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserserviceService } from 'src/app/userservice.service';
import { Http, Response } from '@angular/http';
import  {  HttpClient,  HttpHeaders }  from  '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.scss']
})
export class AddCustomerComponent implements OnInit {

  flag: boolean;
  date1: any;
  toDate: string;
  date2: any;
  mobile: any;
  date: any;
  cName: any;
  formdata;
  constructor(private userservice: UserserviceService, private toastrService: ToastrService) { }

  ngOnInit() {
    this.formdata = new FormGroup({
      cname: new FormControl(),
      phone: new FormControl(),
      date: new FormControl()
    });
  }

  onClickSubmit(data) {
    this.cName = data.cname;
    let date1 = data.date;
    this.toDate = `${date1.getFullYear()}-${date1.getMonth() + 1}-${date1.getDate()}`;
    console.log("from calenadr  ",date1);
    this.date2 = date1[0];
    console.log(this.date2);
    this.mobile = data.phone;
    console.log(this.cName, this.toDate, this.mobile);

    let dataObject = {
      "userName": this.cName,
      "mobileNo": this.mobile,
      "birthDate": date1
    }

    this.userservice.saveCustomerData(dataObject).subscribe((response : any) => {
      console.log("added user ... ",response);
      this.flag = response.success;
      if(this.flag == true){
        this.toastrService.success('', 'Customter Added Successfully !');
      }else{
        this.toastrService.error('', 'Invalid!');
      }
      
    });
}
}
