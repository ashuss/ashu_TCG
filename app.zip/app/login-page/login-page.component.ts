import { Component, OnInit } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Router} from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserserviceService } from 'src/app/userservice.service';
import  {  HttpClient,  HttpHeaders }  from  '@angular/common/http';
import { Http, Response } from '@angular/http';
@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent implements OnInit {

  flag: boolean;
  pass: any;
  uName: any;
  formdata;  
  constructor( private router: Router, private toastrService: ToastrService, private userservice: UserserviceService) { }

  ngOnInit() {
    this.formdata = new FormGroup({
      uname: new FormControl(),
      passwd: new FormControl()
   });
  }
  onClickSubmit(data) {
    console.log("Login Page Data ... " , data);
    this.uName = data.uname;
    this.pass = data.passwd;

    let loginData = {
      "userName":  this.uName,
      "password": this.pass
    }
    this.userservice.userLogin(loginData).subscribe((response : any) => {
      console.log("POST Request is successful ", response);
      this.flag = response.success;
      console.log("flas set .... ",this.flag);
      if( this.flag == true ){
        this.toastrService.success('', 'Successfull !');
        this.router.navigate(['/Home']);
      }else{
        this.toastrService.error('Invalid', 'Credentials !');
        return false;
      }
      
    });

  }
}
