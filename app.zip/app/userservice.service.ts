import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Http,Headers }   from '@angular/http';
import { HttpClient, HttpHeaders} from '@angular/common/http';  

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {
headers: HttpHeaders = new HttpHeaders({ 
'Content-Type':'application/json'
}); 

  constructor(public http:  HttpClient) { }

  userLogin(loginData){
    return this.http.post('http://localhost:8097/login',loginData,{headers: this.headers});
  }

  saveCustomerData(userData){
   return this.http.post('http://localhost:8097/addCustomerData',userData,{headers: this.headers});
  }
}
