import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {

  add: boolean = true;
  wish: boolean = false;
  notification: boolean = false;
  constructor() { }

  ngOnInit() {


  }

  addCustomer() {
    this.add = true;
    this.wish = false;
    this.notification = false;
  }
  sendWish(){
    this.add = false;
    this.wish = true;
    this.notification = false;
  }
  sendNotification(){
    this.add = false;
    this.wish = false;
    this.notification = true;
  }


}
