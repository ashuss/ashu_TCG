package com.sd.fashionzone.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.sd.fashionzone.entity.LoginDtoEntity;
import com.sd.fashionzone.entity.UserDetailsEntity;

public interface UserDetailsRepository extends JpaRepository<UserDetailsEntity, Long> {
	
	@Query("SELECT user FROM UserDetailsEntity user")
	public List<UserDetailsEntity> getUsersByBirthdate();
	
	@Query("SELECT user.mobileNo FROM UserDetailsEntity user WHERE user.birthDate=?1")
	public List<Long> getPhoneNumberByBday(Date bDay);
	
	@Query("SELECT loginMaster FROM LoginDtoEntity loginMaster WHERE loginMaster.userName = ?1 AND loginMaster.password = ?2")
	LoginDtoEntity findUserbyUserName(String userName, String password);
	
	@Query("SELECT login FROM LoginDtoEntity login")
	public List<LoginDtoEntity> getAdminData();

}
