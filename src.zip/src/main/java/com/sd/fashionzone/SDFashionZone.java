package com.sd.fashionzone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SDFashionZone {

	public static void main(String[] args) {
		SpringApplication.run(SDFashionZone.class,args);

	}

}
