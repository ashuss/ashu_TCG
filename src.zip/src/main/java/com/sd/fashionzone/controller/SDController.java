package com.sd.fashionzone.controller;

import java.io.IOException;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sd.fashionzone.dtos.LoginDto;
import com.sd.fashionzone.dtos.ResponseDto;
import com.sd.fashionzone.dtos.UserDetailsDto;
import com.sd.fashionzone.services.IUserDetailsService;

//@CrossOrigin(origin = "http://localhost:4200")
@RestController
public class SDController {

	@Autowired
	IUserDetailsService iUser;

	@RequestMapping(value = "/addCustomerData", method = RequestMethod.POST)
	public ResponseDto addUserData(@RequestBody UserDetailsDto userDto) throws IOException {
		return iUser.addCustomerData(userDto);
	}

	@RequestMapping("/getUserData")
	public List<UserDetailsDto> getUsersByBday() throws IOException {
		return iUser.getAllUserData();
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseDto userLogin(@RequestBody LoginDto logInDto) throws IOException {
		return iUser.logIn(logInDto);
	}

}
