package com.sd.fashionzone.services;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import javax.net.ssl.SSLHandshakeException;

import java.net.*;
import java.io.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sd.fashionzone.services.IEntityDtoMapper;
import com.sd.fashionzone.dtos.LoginDto;
import com.sd.fashionzone.dtos.ResponseDto;
import com.sd.fashionzone.dtos.UserDetailsDto;
import com.sd.fashionzone.entity.LoginDtoEntity;
import com.sd.fashionzone.entity.UserDetailsEntity;
import com.sd.fashionzone.repository.UserDetailsRepository;

@Service
public class UserDetailsServiceImpl implements IUserDetailsService {
	@Autowired
	UserDetailsRepository userDetailsRepository;

	@Autowired
	IEntityDtoMapper mapper;

	static final String _userName = "7506382849";
	static final String _password = "Ashu123";
	static final String _url = "http://ubaid.tk/sms/sms.aspx";
	static final String _loginUrl = "https://smsapi.engineeringtgr.com/login/?Mobile=&Password=";
	static final String _sendUrl = "https://smsapi.engineeringtgr.com/send/?Mobile=&Password=&Message=&To=&Key=";
	static final String charset = "UTF-8";
	static final String message = "Test Message";
	static final String apiKey = "sheda1q4GKPrIdSUyvmslxiZH";
	
	@Override
	public ResponseDto addCustomerData(UserDetailsDto userDto) {
		ResponseDto response = new ResponseDto();
		if (userDto.getUserName() != null && userDto.getUserName() != "" && userDto.getMobileNo() != null
				&& userDto.getBirthDate() != null) {

			UserDetailsEntity userDetailsEntity = new UserDetailsEntity();
			userDetailsEntity.setUserName(userDto.getUserName());
			userDetailsEntity.setMobileNo(userDto.getMobileNo());
			userDetailsEntity.setBirthDate(userDto.getBirthDate());
			UserDetailsEntity saveUserDeatilsEntity = userDetailsRepository.save(userDetailsEntity);
			response.setSuccess(true);
			response.setData("User Added Successfully");
		} else {
			response.setSuccess(false);
			response.setData("userName already exists.. ");
		}
		return response;
	}

	@Override
	public List<UserDetailsDto> getAllUserData() {
		List<UserDetailsDto> userDetailsDtos = null;
		userDetailsDtos = new ArrayList<>();

		Date today = new Date();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String today1 = dateFormat.format(today);
		System.out.println("todays date string  ...... " + today1);

		List<UserDetailsEntity> userDetailsEntityList = userDetailsRepository.getUsersByBirthdate();
		for (UserDetailsEntity userDetailsEntity : userDetailsEntityList) {
			Date bday = userDetailsEntity.getBirthDate();
			Timestamp bday1 = new Timestamp(bday.getTime());
			// System.out.println("timestamp bady ......... "+bday1);
			Date date = new Date(bday1.getTime());
			String bday2 = dateFormat.format(date);
			System.out.println("bday string  ........ " + bday2);
			if (today1.equals(bday2)) {
				ArrayList<Long> contactList = (ArrayList<Long>) userDetailsRepository.getPhoneNumberByBday(date);
				System.out.println("list of contact equals .... " + contactList);
				for(int i=0; i < contactList.size(); i++ ){
					try {
//						buildRequestString(contactList.get(i).toString(),message);
//						sendSMS(contactList.get(i).toString(),message);
						sendSMSTest(_userName,_password,message,contactList.get(i).toString(),apiKey);
					} catch (Exception e) {
						
						e.printStackTrace();
					}
				}
				
			}
			UserDetailsDto userDetailsDtoMapper = mapper.userDetailsMapping(userDetailsEntity);
			userDetailsDtos.add(userDetailsDtoMapper);
		}

		return userDetailsDtos;
	}
	
	private void sendSMSTest(String username, String password, String message2, String to, String apikey2) {
		try {
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cis-india-pitc-bangalorez.proxy.corporate.ge.com", 80));
            URL url = new URL("https://smsapi.engineeringtgr.com/send/?Mobile=username&Password=password&Message=message2&To=to&Key=apikey2");
            URLConnection urlcon = url.openConnection(proxy);
            InputStream stream = urlcon.getInputStream();
            int i;
            String response="";
            while ((i = stream.read()) != -1) {
                response+=(char)i;
            }
            if(response.contains("success")){
                System.out.println("Successfully send SMS");
                //your code when message send success
            }else{
                System.out.println(response);
                //your code when message not send
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
		
	}

	private String buildRequestString(String targetPhoneNo, String sms) throws UnsupportedEncodingException {
		
		System.out.println("Inside buildRequestString");
		
		String [] params = new String [5];
		params[0] = _userName;
		params[1] = _password;
		params[2] = sms;
		params[3] = targetPhoneNo;
		params[4] = "way2sms";
		
		String query = String.format("uid=%s&pwd=%s&msg=%s&phone=%s&provider=%s",
				URLEncoder.encode(params[0],charset),
				URLEncoder.encode(params[1],charset),
				URLEncoder.encode(params[2],charset),
				URLEncoder.encode(params[3],charset),
				URLEncoder.encode(params[4],charset)
				);
		return query;
		
	}
	

	private ResponseDto sendSMS(String reciever, String message) throws Exception {
		
		System.out.println("Inside sendSMS");
		
		ResponseDto response = new ResponseDto();
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cis-india-pitc-bangalorez.proxy.corporate.ge.com", 80));
		URLConnection connection = new URL(_url + "?" + buildRequestString(reciever,message)).openConnection(proxy);
		connection.setRequestProperty("Accept-Charset", charset);
		InputStream response1 = connection.getInputStream();
		BufferedReader br = new BufferedReader(new InputStreamReader(response1));
		System.out.println(br.readLine());
		response.setSuccess(true);
		response.setData("SMS send Successfully");
		
		return response;

	}

	


	@Override
	public ResponseDto logIn(LoginDto loginDto) {
		ResponseDto response = new ResponseDto();
		if (loginDto.getUserName() != "" && loginDto.getUserName() != null && loginDto.getPassword() != ""
				&& loginDto.getPassword() != null) {
			LoginDtoEntity loginDtoEntity = userDetailsRepository.findUserbyUserName(loginDto.getUserName(),loginDto.getPassword());
			if (loginDtoEntity != null) {
				response.setSuccess(true);
				response.setData(loginDtoEntity.getUserName());
			} else {
				response.setSuccess(false);
				response.setData("Username or Password is incorrect..!!");
			}

		} else {
			response.setSuccess(false);
			response.setData("Field can't be blank");
		}
		return response;
	}

	
}
