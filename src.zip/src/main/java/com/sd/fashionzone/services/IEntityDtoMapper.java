package com.sd.fashionzone.services;

import com.sd.fashionzone.dtos.LoginDto;
import com.sd.fashionzone.dtos.UserDetailsDto;
import com.sd.fashionzone.entity.LoginDtoEntity;
import com.sd.fashionzone.entity.UserDetailsEntity;

public interface IEntityDtoMapper {
	
	public UserDetailsDto userDetailsMapping(UserDetailsEntity userDetailsEntity);
	
	public LoginDto loginDetailsMapping(LoginDtoEntity userDetailsEntity);

}
