package com.sd.fashionzone.services;

import org.springframework.stereotype.Service;

import com.sd.fashionzone.dtos.LoginDto;
import com.sd.fashionzone.dtos.UserDetailsDto;
import com.sd.fashionzone.entity.LoginDtoEntity;
import com.sd.fashionzone.entity.UserDetailsEntity;

@Service
public class EntityDtoMapperImpl implements IEntityDtoMapper{

	@Override
	public UserDetailsDto userDetailsMapping(UserDetailsEntity userDetailsEntity) {
		UserDetailsDto userDetailsDto = new UserDetailsDto();
		userDetailsDto.setUserId(userDetailsEntity.getUserId());
		userDetailsDto.setUserName(userDetailsEntity.getUserName());
		userDetailsDto.setMobileNo(userDetailsEntity.getMobileNo());
		userDetailsDto.setBirthDate(userDetailsEntity.getBirthDate());
		return userDetailsDto;
	}

	@Override
	public LoginDto loginDetailsMapping(LoginDtoEntity loginDtoEntity) {
		LoginDto loginDto = new LoginDto();
		loginDto.setUserName(loginDtoEntity.getUserName());
		loginDto.setPassword(loginDtoEntity.getPassword());
		return loginDto;
	}

}
