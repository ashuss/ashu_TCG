package com.sd.fashionzone.services;

import java.util.Date;
import java.util.List;

import com.sd.fashionzone.dtos.LoginDto;
import com.sd.fashionzone.dtos.ResponseDto;
import com.sd.fashionzone.dtos.UserDetailsDto;
import com.sd.fashionzone.entity.UserDetailsEntity;

public interface IUserDetailsService {

	public ResponseDto addCustomerData(UserDetailsDto userDto);
	public List<UserDetailsDto> getAllUserData();
	public ResponseDto logIn(LoginDto loginDto);
	
}
