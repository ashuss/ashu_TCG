package com.cg.simulator.dto;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.sql.Timestamp;
import java.util.Random;

import com.amazonaws.services.iot.client.AWSIotException;
import com.amazonaws.services.iot.client.AWSIotMessage;
import com.amazonaws.services.iot.client.AWSIotMqttClient;
import com.amazonaws.services.iot.client.AWSIotQos;
import com.cg.simulator.aws.Util;
import com.cg.simulator.aws.Util.KeyStorePasswordPair;

public class AwsConnector {

	private static final String clientEndpoint = "a3d0kl6pnel8kx.iot.us-east-1.amazonaws.com";
	private static final String clientId = "Subway_POC_66333_Core";
	private static final String certificateFile = "118eb3ba7c.cert.pem";
	private static final String privateKeyFile = "118eb3ba7c.private.key"; // X.509
	private static final String topicName = "Test/Migration/FSM";
	private static final AWSIotQos topicQos = AWSIotQos.QOS0;
	private static final Random randomNum = new Random();
	private Thread t;
	private Timestamp timestamp; 
	private AWSIotMqttClient awsIotClient;
	private KeyStorePasswordPair pair;
	private String request;
	
	public static String getCurrent(int min, int max) {

		return String.valueOf(randomNum.nextInt(max - min) + min);
	}

	public AwsConnector() {
		try {
			System.out.println("I am Here....................");
			pair = Util.getKeyStorePasswordPair(certificateFile, privateKeyFile);
			this.awsIotClient = new AWSIotMqttClient(clientEndpoint, clientId, pair.keyStore, pair.keyPassword);
			this.awsIotClient.connect();
			
		} catch (IOException ie) {
			System.out.println("IOException While loading Certificates ");
			ie.printStackTrace();
		} catch (GeneralSecurityException gse) {
			System.out.println("GeneralSecurityException While loading Certificates ");
			gse.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception While loading Certificates ");
			e.printStackTrace();
		}

	}
	
	public void disconnectClient(){
		try {
			this.awsIotClient.disconnect();
		} catch (AWSIotException e) {
			e.printStackTrace();
		}
	}

	public void publish(String rpm)
			throws InterruptedException {

		
		System.out.println("status---------------------" + awsIotClient.getConnectionStatus());
		
		if (awsIotClient.getConnectionStatus().equals("DISCONNECTED")) {
			this.awsIotClient = new AWSIotMqttClient(clientEndpoint, clientId, pair.keyStore, pair.keyPassword);
			try {
				this.awsIotClient.connect();
			} catch (AWSIotException e) {

				e.printStackTrace();
			}
		}

		this.timestamp = new Timestamp(System.currentTimeMillis());

		// oven
		long ovenTimeStamp = this.timestamp.getTime();
		this.request = "{\"timestamp\": " + ovenTimeStamp+ ",\"rpm\":\"" + rpm + "\"}";
		t = new Thread(new NonBlockingPublisher(this.awsIotClient, topicName,
				topicQos, this.request));
		t.start();

		//Thread.sleep(10);
		
	}

	// implements Runnable
	public class NonBlockingPublisher implements Runnable {
		private AWSIotMessage message;
		private AWSIotMqttClient awsClient;

		public NonBlockingPublisher(AWSIotMqttClient awsIotClient, String topic, AWSIotQos qos, String payload) {

			awsClient = awsIotClient;
			this.message = new NonBlockingPublishListener(topic, qos, payload);
		}

		@Override
		public void run() {
			
			try {
				awsClient.publish(this.message);

			} catch (AWSIotException awsiote) {
				System.out.println("AWSIotException while publishing the message: " + this.message.getTopic());
				awsiote.printStackTrace();
			} catch (Exception ex) {
				System.out.println("Exception while publishing the message: " + this.message.getTopic());
				ex.printStackTrace();
			}
		}

	}

	public static void main(String[] args) {

	}

	public class NonBlockingPublishListener extends AWSIotMessage {
		String qtopic;

		public NonBlockingPublishListener(String topic, AWSIotQos qos, String payload) {
			super(topic, qos, payload);
			this.qtopic = topic;
		}

		@Override
		public void onSuccess() {
			// called when message publishing succeeded
			System.out.println("Connected Succesfully: " + this.qtopic);
		}

		@Override
		public void onFailure() {
			// called when message publishing failed
			System.out.println("Connection Failed: " + this.qtopic);
		}

		@Override
		public void onTimeout() {
			// called when message publishing timed out
			System.out.println("Connection Timed Out: " + this.qtopic);
		}
	}
	
}
