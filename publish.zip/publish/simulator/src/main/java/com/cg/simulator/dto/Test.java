
package simulator.src.main.java.com.cg.simulator.dto;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;

public class Test {
     static DynamoDB dynamoDB = new DynamoDB(new AmazonDynamoDBClient(new ProfileCredentialsProvider()));
    static String tblName = "Fsm_table";
    public static void main(String[] args) throws IOException, InterruptedException {
      
    
        String content = new String(Files.readAllBytes(Paths.get("/home/pi/Documents/FSM/RPMCount/rpm.txt")));
        System.out.println("content "+content);
        AwsConnector aws = new AwsConnector();
       while(true){
        aws.publish(content);
        Thread.sleep(1000);
    }
    		fetchItems();
    
  
    
}
private static ArrayList<Long> fetchItems() {
	     AmazonDynamoDBClient dynamoDBClient = new AmazonDynamoDBClient();
//	     AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().build();
	    ArrayList<Long> timeStampData = new ArrayList<Long>();

	    ScanResult result = null;
	 
	    do{
	        ScanRequest req = new ScanRequest();
	        req.setTableName(tblName);
	 
	        if(result != null){
	            req.setExclusiveStartKey(result.getLastEvaluatedKey());
	        }
	         
	        result = dynamoDBClient.scan(req);
	 
	        List<Map<String, AttributeValue>> rows = result.getItems();
	 
	        for(Map<String, AttributeValue> map : rows){
	        	System.out.println("list parameter"+map);
	            try{
	                AttributeValue v = map.get("timestamp","rpm");
	                String tStamp = v.getS();
	                timeStampData.add(Long.parseLong(tStamp));
	            } catch (NumberFormatException e){
	                System.out.println(e.getMessage());
	            }
	        }
	    } while(result.getLastEvaluatedKey() != null);
	     
	    System.out.println("Result size: " + timeStampData.size());
	 
	    return timeStampData;
	}

}
