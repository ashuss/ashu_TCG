package com.cg.simulator.dto;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Test {
	
	public static void main(String[] args) throws IOException, InterruptedException {
		
		String content = new String(Files.readAllBytes(Paths.get("C:/Users/dhanpawa/Desktop/file.txt")));
		System.out.println("content "+content);
		AwsConnector aws = new AwsConnector();
		aws.publish(content);
	}
}
